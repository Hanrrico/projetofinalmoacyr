

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/sucessodados.css">
    <title>Document</title>
</head>
<body>
    <?php 
    include_once "../factory/conexao.php";
    
    $nome = $_POST["cxnome"];
    $email = $_POST["cxemail"];
    $datanasc = $_POST["cxdatanasc"];
    $tel = $_POST["cxtel"];
    $cod =  $_POST["cxcodigo"];


    $alterar = "
        UPDATE tbamigos SET

        nome = '$nome',
        email = '$email',
        datanasc = '$datanasc',
        tel = '$tel' 
        where
        cod = '$cod'
    ";

    $executar = mysqli_query($conn,$alterar);
    if ($executar){
            echo "Dados Alterados com sucesso!";
    }
    else{
            echo "Erro ao alterar os dados!";
    }
?>

<a href="/projetob/view/telacadamigo.php?action=buscar">Voltar</a> 

<style>
    body{
    background-color: #D6D4DB;
}

.botao-voltar {
    display: inline-block;
    padding: 10px 20px;
    background-color: #757BB1;
    color: #fff;
    text-decoration: none;
    border-radius: 5px;
    transition: background-color 0.3s;
}

.botao-voltar:hover {
    background-color: #0056b3;
}

#cxprincipal{
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
}


</style>
</body>
</html>