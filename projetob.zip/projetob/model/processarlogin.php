<?php
session_start();
include_once "../factory/conexao.php";

$nome = $_POST["cxnome"];
$email = $_POST["cxemail"];
$senha = $_POST["cxsenha"];

$sql = "SELECT * FROM tbusuario WHERE nome = '$nome' AND email = '$email' AND senha = '$senha'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    $_SESSION["nome"] = $nome;
    $_SESSION["email"] = $email;
    $_SESSION["senha"] = $senha;

    header("location: ../view/index.php");
    exit();
} else {
    echo "E-mail e senha errados!<a href='../view/login.php'>Tente Novamente </a>";
    unset($_SESSION["nome"]);
    unset($_SESSION["email"]);
    unset($_SESSION["senha"]);
}
?>